package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseManager
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioDashboard(
    firebaseManager: FirebaseManager,
    onBack: () -> Unit,
    onNavigateToVideo: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    
    val channelId = firebaseManager.getCurrentUserId() ?: ""
    
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkBackground)
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(BrandRedGradientStart, BrandRed)))
                            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("PV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            "PlayVibe Studio",
                            color = DarkOnSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            "CREATOR DASHBOARD",
                            color = TextMuted,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DarkSurface)
                        .border(1.dp, BorderColor, CircleShape)
                        .clickable { onBack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = BrandRedLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF120D0D))
                    .border(1.dp, BorderColor)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CustomNavItem(
                    icon = Icons.Filled.Dashboard,
                    label = "Dashboard",
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                CustomNavItem(
                    icon = Icons.Filled.VideoLibrary,
                    label = "Content",
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                CustomNavItem(
                    icon = Icons.Filled.Analytics,
                    label = "Analytics",
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 }
                )
                CustomNavItem(
                    icon = Icons.Filled.Comment,
                    label = "Comments",
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    hasNotification = true
                )
                CustomNavItem(
                    icon = Icons.Filled.MonetizationOn,
                    label = "Earn",
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 }
                )
            }
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize().background(DarkBackground)) {
            when (selectedTab) {
                0 -> DashboardOverviewTab(firebaseManager, channelId)
                1 -> ContentTab(firebaseManager, channelId, onNavigateToVideo)
                2 -> AnalyticsTab(firebaseManager, channelId)
                3 -> CommentsTab(firebaseManager, channelId)
                4 -> EarnTab()
            }
        }
    }
}

@Composable
fun CustomNavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    hasNotification: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .let {
                    if (selected) {
                        it.background(BrandRed.copy(alpha = 0.2f), shape = RoundedCornerShape(16.dp))
                    } else {
                        it
                    }
                }
                .padding(8.dp)
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (selected) BrandRed else Color.White.copy(alpha = 0.4f),
                modifier = Modifier.size(24.dp)
            )
            if (hasNotification && !selected) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(BrandRed)
                        .border(1.dp, Color(0xFF120D0D), CircleShape)
                        .align(Alignment.TopEnd)
                        .offset(x = 2.dp, y = (-2).dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) BrandRed else Color.White.copy(alpha = 0.4f)
        )
    }
}
