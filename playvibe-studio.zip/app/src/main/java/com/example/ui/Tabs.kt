package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import com.example.data.Channel
import com.example.data.Comment
import com.example.data.FirebaseManager
import com.example.data.Video
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- Dashboard Tab ---
@Composable
fun DashboardOverviewTab(firebaseManager: FirebaseManager, channelId: String) {
    var channel by remember { mutableStateOf<Channel?>(null) }
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(channelId) {
        channel = firebaseManager.getChannel(channelId)
        videos = firebaseManager.getVideosForChannel(channelId)
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = com.example.ui.theme.BrandRed)
        }
        return
    }

    val views = videos.sumOf { it.views }
    val watchTime = videos.sumOf { it.views * it.averageWatchDurationHours }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Profile & Subs Summary
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(com.example.ui.theme.DarkSurface, Color(0xFF120D0D))
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .border(
                    1.dp,
                    com.example.ui.theme.BorderColor,
                    RoundedCornerShape(24.dp)
                )
                .padding(20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                color = com.example.ui.theme.DarkBackground,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .border(
                                2.dp,
                                com.example.ui.theme.BrandRedGradientStart,
                                RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.Person, contentDescription = null, tint = com.example.ui.theme.TextMuted)
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(channel?.name ?: "Unknown Channel", color = com.example.ui.theme.DarkOnSurface, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("${channel?.subscriberCount ?: 0} subscribers", color = com.example.ui.theme.TextMuted, style = MaterialTheme.typography.bodySmall)
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Views Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                color = com.example.ui.theme.DarkBackground,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .border(
                                1.dp,
                                com.example.ui.theme.BorderColor,
                                RoundedCornerShape(16.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text("VIEWS", color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            when {
                                views >= 1000 -> String.format(Locale.US, "%.1fK", views / 1000.0)
                                else -> "$views"
                            },
                            color = com.example.ui.theme.BrandRedLight,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("↑ 12% vs last 28d", color = com.example.ui.theme.SuccessGreen, fontSize = 10.sp)
                    }
                    
                    // Watch Time Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                color = com.example.ui.theme.DarkBackground,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .border(
                                1.dp,
                                com.example.ui.theme.BorderColor,
                                RoundedCornerShape(16.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text("WATCH TIME", color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                when {
                                    watchTime >= 1000 -> String.format(Locale.US, "%.1fK", watchTime / 1000.0)
                                    else -> String.format(Locale.US, "%.1f", watchTime)
                                },
                                color = com.example.ui.theme.BrandRedLight,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("hrs", color = com.example.ui.theme.TextMuted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 2.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("↑ 8% vs last 28d", color = com.example.ui.theme.SuccessGreen, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// --- Content Tab ---
@Composable
fun ContentTab(firebaseManager: FirebaseManager, channelId: String, onNavigateToVideo: (String) -> Unit) {
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(channelId) {
        videos = firebaseManager.getVideosForChannel(channelId).sortedByDescending { it.uploadDate }
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = com.example.ui.theme.BrandRed) }
        return
    }
    
    if (videos.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No videos found", color = com.example.ui.theme.TextMuted) }
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text("LATEST CONTENT", color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            Text("View All", color = com.example.ui.theme.BrandRedLight, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(videos) { video ->
                VideoListItem(video = video, onClick = { onNavigateToVideo(video.id) })
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun VideoListItem(video: Video, onClick: () -> Unit) {
    val dateFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
    val dateStr = if (video.uploadDate > 0) dateFormat.format(Date(video.uploadDate)) else "Unknown Date"
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(com.example.ui.theme.DarkSurface, shape = RoundedCornerShape(16.dp))
            .border(1.dp, com.example.ui.theme.BorderColor, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .width(96.dp)
                    .height(54.dp)
                    .background(Color(0xFF0F172A), shape = RoundedCornerShape(12.dp))
                    .clip(RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.BottomEnd
            ) {
                // Gradient overlay
                Box(modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f))
                    )
                ))
                Text(
                    "12:45",
                    color = Color.White,
                    fontSize = 9.sp,
                    modifier = Modifier.padding(4.dp).background(Color.Black.copy(alpha = 0.8f), shape = RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column {
                Text(video.title, color = com.example.ui.theme.DarkOnSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 4.dp)) {
                    Text(
                        when {
                            video.views >= 1000 -> String.format(Locale.US, "%.1fK views", video.views / 1000.0)
                            else -> "${video.views} views"
                        },
                        color = com.example.ui.theme.TextMuted,
                        fontSize = 10.sp
                    )
                    Text(dateStr, color = com.example.ui.theme.TextMuted, fontSize = 10.sp)
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                if (video.isCopyrightClaimed) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(com.example.ui.theme.WarningAmber.copy(alpha = 0.1f), shape = RoundedCornerShape(12.dp))
                            .border(1.dp, com.example.ui.theme.WarningAmber.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(10.dp), tint = com.example.ui.theme.WarningAmber)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("COPYRIGHT CLAIM", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.WarningAmber)
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(com.example.ui.theme.SuccessGreen.copy(alpha = 0.1f), shape = RoundedCornerShape(12.dp))
                            .border(1.dp, com.example.ui.theme.SuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(10.dp), tint = com.example.ui.theme.SuccessGreen)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("NO ISSUES", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.SuccessGreen)
                    }
                }
            }
        }
    }
}

// --- Analytics Tab ---
@Composable
fun AnalyticsTab(firebaseManager: FirebaseManager, channelId: String) {
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(channelId) {
        videos = firebaseManager.getVideosForChannel(channelId)
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = com.example.ui.theme.BrandRed) }
        return
    }

    val topVideos = videos.sortedByDescending { it.views }.take(3)

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("TOP PERFORMING", color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
        Spacer(modifier = Modifier.height(16.dp))
        
        topVideos.forEachIndexed { index, video ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .background(com.example.ui.theme.DarkSurface, shape = RoundedCornerShape(16.dp))
                    .border(1.dp, com.example.ui.theme.BorderColor, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "#${index + 1}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = com.example.ui.theme.BrandRedLight
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(video.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = com.example.ui.theme.DarkOnSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${video.views} views", style = MaterialTheme.typography.bodyMedium, color = com.example.ui.theme.TextMuted)
                }
            }
        }
    }
}

// --- Comments Tab ---
@Composable
fun CommentsTab(firebaseManager: FirebaseManager, channelId: String) {
    var comments by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(channelId) {
        comments = firebaseManager.getCommentsForChannel(channelId)
        isLoading = false
    }

    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = com.example.ui.theme.BrandRed) }
        return
    }
    
    if (comments.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No comments found", color = com.example.ui.theme.TextMuted) }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Text("LATEST COMMENTS", color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(16.dp))
        }
        items(comments) { comment ->
            CommentItem(comment, firebaseManager)
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun CommentItem(comment: Comment, firebaseManager: FirebaseManager) {
    var isReplying by remember { mutableStateOf(false) }
    var replyText by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    val dateFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
    val dateStr = if (comment.timestamp > 0) dateFormat.format(Date(comment.timestamp)) else ""

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(com.example.ui.theme.DarkSurface, shape = RoundedCornerShape(16.dp))
            .border(1.dp, com.example.ui.theme.BorderColor, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(32.dp).background(com.example.ui.theme.DarkBackground, shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(comment.commenterName.take(1).uppercase(), color = com.example.ui.theme.TextMuted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(comment.commenterName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = com.example.ui.theme.DarkOnSurface)
                    Text(dateStr, fontSize = 10.sp, color = com.example.ui.theme.TextMuted)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(comment.text, fontSize = 14.sp, color = com.example.ui.theme.DarkOnSurface)
            Spacer(modifier = Modifier.height(12.dp))
            
            Box(
                modifier = Modifier
                    .background(com.example.ui.theme.DarkBackground, shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("On: ${comment.videoTitle}", fontSize = 10.sp, color = com.example.ui.theme.TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            if (isReplying) {
                OutlinedTextField(
                    value = replyText,
                    onValueChange = { replyText = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Add a reply...", color = com.example.ui.theme.TextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = com.example.ui.theme.BrandRedLight,
                        unfocusedBorderColor = com.example.ui.theme.BorderColor,
                        focusedTextColor = com.example.ui.theme.DarkOnSurface,
                        unfocusedTextColor = com.example.ui.theme.DarkOnSurface
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { isReplying = false }) { Text("Cancel", color = com.example.ui.theme.TextMuted) }
                    Button(
                        onClick = {
                            isSubmitting = true
                            scope.launch {
                                firebaseManager.addReply(comment.videoId, comment.id, replyText, comment.videoTitle)
                                isReplying = false
                                isSubmitting = false
                            }
                        },
                        enabled = !isSubmitting && replyText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.BrandRed, disabledContainerColor = com.example.ui.theme.BrandRed.copy(alpha = 0.5f))
                    ) {
                        Text("Reply", color = Color.White)
                    }
                }
            } else {
                OutlinedButton(
                    onClick = { isReplying = true },
                    border = BorderStroke(1.dp, com.example.ui.theme.BorderColor),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.BrandRedLight)
                ) {
                    Text("Reply")
                }
            }
        }
    }
}

// --- Earn Tab ---
@Composable
fun EarnTab() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(com.example.ui.theme.BrandRed.copy(alpha = 0.1f), shape = CircleShape)
                .border(1.dp, com.example.ui.theme.BrandRed.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MonetizationOn, contentDescription = null, modifier = Modifier.size(48.dp), tint = com.example.ui.theme.BrandRedLight)
        }
        Spacer(modifier = Modifier.height(32.dp))
        Text("Monetization", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = com.example.ui.theme.DarkOnSurface)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Become a partner to earn money from your videos.", textAlign = TextAlign.Center, color = com.example.ui.theme.TextMuted)
        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = { /* */ },
            colors = ButtonDefaults.buttonColors(containerColor = com.example.ui.theme.BrandRed)
        ) {
            Text("Apply Now", color = Color.White)
        }
    }
}
