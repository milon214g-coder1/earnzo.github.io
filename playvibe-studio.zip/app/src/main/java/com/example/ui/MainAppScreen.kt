package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseManager
import com.example.ui.theme.*

@Composable
fun MainAppScreen(
    firebaseManager: FirebaseManager,
    onNavigateToStudio: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF120D0D))
                    .border(1.dp, BorderColor)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CustomNavItem(
                    icon = if (selectedTab == 0) Icons.Filled.Home else Icons.Outlined.Home,
                    label = "Home",
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 }
                )
                CustomNavItem(
                    icon = if (selectedTab == 1) Icons.Filled.PlayArrow else Icons.Outlined.PlayArrow,
                    label = "Shorts",
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 }
                )
                // Center Add Button
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(BrandRed)
                        .clickable { selectedTab = 2 },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.AddCircle, contentDescription = "Upload", tint = Color.White, modifier = Modifier.size(32.dp))
                }
                CustomNavItem(
                    icon = if (selectedTab == 3) Icons.Filled.VideoLibrary else Icons.Outlined.VideoLibrary,
                    label = "My Vibes",
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 }
                )
                CustomNavItem(
                    icon = if (selectedTab == 4) Icons.Filled.Person else Icons.Outlined.Person,
                    label = "You",
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 }
                )
            }
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize().background(DarkBackground)) {
            when (selectedTab) {
                0 -> HomeTab(firebaseManager)
                1 -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Shorts Feed (Coming Soon)", color = TextMuted)
                }
                2 -> UploadTab(firebaseManager, onUploadComplete = { selectedTab = 0 })
                3 -> MyVibesTab(firebaseManager)
                4 -> YouProfileScreen(firebaseManager, onNavigateToStudio, onLogout)
            }
        }
    }
}

@Composable
fun YouProfileScreen(
    firebaseManager: FirebaseManager,
    onNavigateToStudio: () -> Unit,
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(48.dp))
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(BrandRedGradientStart, BrandRed)))
                .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("PV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 36.sp)
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text("Logged In User", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = DarkOnSurface)
        Text(firebaseManager.getCurrentUserId() ?: "Not Authed", fontSize = 14.sp, color = TextMuted)
        
        Spacer(modifier = Modifier.height(48.dp))
        
        Button(
            onClick = onNavigateToStudio,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Filled.Settings, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Creator Studio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        OutlinedButton(
            onClick = { 
                firebaseManager.logout()
                onLogout()
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandRedLight)
        ) {
            Text("Sign Out", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
