package com.example.data

import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirebaseManager {
    private var firestore: FirebaseFirestore? = null
    private var auth: FirebaseAuth? = null

    var isInitialized = false
        private set

    init {
        try {
            FirebaseApp.getInstance()
            firestore = FirebaseFirestore.getInstance()
            auth = FirebaseAuth.getInstance()
            isInitialized = true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Firebase not initialized. Add google-services.json.", e)
            isInitialized = false
        }
    }

    // Auth
    fun getCurrentUserId(): String? {
        return auth?.currentUser?.uid
    }
    
    fun isUserLoggedIn(): Boolean {
        return auth?.currentUser != null
    }

    suspend fun login(email: String, password: String): Boolean {
        if (!isInitialized) return false
        return try {
            auth?.signInWithEmailAndPassword(email, password)?.await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Login failed", e)
            false
        }
    }
    
    fun logout() {
        auth?.signOut()
    }

    // Channels
    suspend fun getChannel(channelId: String): Channel? {
        if (!isInitialized) return null
        return try {
            val doc = firestore?.collection("channels")?.document(channelId)?.get()?.await()
            doc?.toObject(Channel::class.java)?.copy(id = doc.id)
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error getting channel", e)
            null
        }
    }

    // Videos
    suspend fun getAllVideos(): List<Video> {
        if (!isInitialized) return emptyList()
        return try {
            val snapshot = firestore?.collection("videos")?.get()?.await()
            snapshot?.documents?.mapNotNull { doc ->
                doc.toObject(Video::class.java)?.copy(id = doc.id)
            } ?: emptyList()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error getting all videos", e)
            emptyList()
        }
    }

    suspend fun uploadVideo(title: String, videoUrl: String, thumbnailUrl: String) {
        if (!isInitialized) return
        val uid = getCurrentUserId() ?: return
        try {
            val newVideo = Video(
                uploaderChannelId = uid,
                title = title,
                videoUrl = videoUrl,
                thumbnailUrl = thumbnailUrl,
                uploadDate = System.currentTimeMillis(),
                views = 0,
                likes = 0,
                commentCount = 0
            )
            firestore?.collection("videos")?.add(newVideo)?.await()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error uploading video", e)
        }
    }

    suspend fun getVideosForChannel(channelId: String): List<Video> {
        if (!isInitialized) return emptyList()
        return try {
            val snapshot = firestore?.collection("videos")
                ?.whereEqualTo("uploaderChannelId", channelId)
                ?.get()?.await()
            snapshot?.documents?.mapNotNull { doc ->
                doc.toObject(Video::class.java)?.copy(id = doc.id)
            } ?: emptyList()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error getting videos", e)
            emptyList()
        }
    }
    
    suspend fun getVideo(videoId: String): Video? {
        if (!isInitialized) return null
        return try {
            val doc = firestore?.collection("videos")?.document(videoId)?.get()?.await()
            doc?.toObject(Video::class.java)?.copy(id = doc.id)
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error getting video", e)
            null
        }
    }

    // Comments
    suspend fun getCommentsForChannel(channelId: String): List<Comment> {
        if (!isInitialized) return emptyList()
        // In a real scenario, this would be a complex query or you'd get videos first, then comments
        // For simplicity, assuming comments have a field or we just get videos first
        val videos = getVideosForChannel(channelId)
        val videoIds = videos.map { it.id }
        if (videoIds.isEmpty()) return emptyList()

        return try {
            // Firestore 'in' query supports up to 10 items. Handling that is complex.
            // A simpler approach for the dashboard is to query comments per video
            val allComments = mutableListOf<Comment>()
            for (vid in videoIds) {
                val comments = getCommentsForVideo(vid)
                allComments.addAll(comments)
            }
            allComments.sortedByDescending { it.timestamp }
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error getting comments", e)
            emptyList()
        }
    }

    suspend fun getCommentsForVideo(videoId: String): List<Comment> {
         if (!isInitialized) return emptyList()
         return try {
             val snapshot = firestore?.collection("comments")
                 ?.whereEqualTo("videoId", videoId)
                 ?.get()?.await()
             snapshot?.documents?.mapNotNull { doc ->
                 doc.toObject(Comment::class.java)?.copy(id = doc.id)
             } ?: emptyList()
         } catch (e: Exception) {
             Log.e("FirebaseManager", "Error getting comments", e)
             emptyList()
         }
    }

    suspend fun addReply(videoId: String, commentId: String, text: String, videoTitle: String) {
        if (!isInitialized) return
        try {
            val reply = Comment(
                videoId = videoId,
                commenterName = "Studio Creator",
                text = text,
                timestamp = System.currentTimeMillis(),
                videoTitle = videoTitle
            )
            firestore?.collection("comments")?.add(reply)?.await()
            // In a real app, we might also update the comment count on the video
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error adding reply", e)
        }
    }
}
