package com.example.data

data class Channel(
    val id: String = "",
    val name: String = "",
    val avatarUrl: String = "",
    val subscriberCount: Int = 0
)

data class Video(
    val id: String = "",
    val uploaderChannelId: String = "",
    val title: String = "",
    val videoUrl: String = "",
    val thumbnailUrl: String = "",
    val uploadDate: Long = 0L,
    val views: Int = 0,
    val likes: Int = 0,
    val commentCount: Int = 0,
    val isCopyrightClaimed: Boolean = false,
    val copyrightClaimDetails: String = "",
    val averageWatchDurationHours: Double = 0.0
)

data class Comment(
    val id: String = "",
    val videoId: String = "",
    val commenterName: String = "",
    val text: String = "",
    val timestamp: Long = 0L,
    val videoTitle: String = ""
)
