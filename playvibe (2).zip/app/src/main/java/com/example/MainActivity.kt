package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PlayVibeApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayVibeApp() {
    var isAuthenticated by remember { mutableStateOf(FirebaseManager.auth.currentUser != null) }
    
    DisposableEffect(Unit) {
        val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { auth ->
            isAuthenticated = auth.currentUser != null
            if (isAuthenticated) {
                FirebaseManager.initFirebaseData()
            }
        }
        FirebaseManager.auth.addAuthStateListener(listener)
        onDispose {
            FirebaseManager.auth.removeAuthStateListener(listener)
        }
    }
    
    if (!isAuthenticated) {
        AuthScreen(onAuthSuccess = { isAuthenticated = true })
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    var showUploadBottomSheet by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentRoute != Screen.Shorts.route && currentRoute?.startsWith("video/") == false) {
                TopAppBar(
                    title = { PlayVibeLogo() },
                    actions = {
                        IconButton(onClick = { /* Search */ }) {
                            Icon(Icons.Filled.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = { navController.navigate("notifications") }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onBackground,
                        actionIconContentColor = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        },
        bottomBar = {
            if (currentRoute?.startsWith("video/") == false) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentColor = MaterialTheme.colorScheme.onBackground
                ) {
                    BottomNavScreens.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.label) },
                            label = { Text(screen.label) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                if (screen.route == Screen.Upload.route) {
                                    showUploadBottomSheet = true
                                } else {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(onVideoClick = { videoId ->
                    navController.navigate("video/$videoId")
                })
            }
            composable(Screen.Shorts.route) { ShortsScreen() }
            composable(Screen.Upload.route) { /* Handled by BottomSheet */ }
            composable(Screen.MyVibes.route) {
                MyVibesScreen(onVideoClick = { videoId ->
                    navController.navigate("video/$videoId")
                })
            }
            composable(Screen.You.route) { 
                YouScreen(
                    onChannelClick = { channelId -> 
                        navController.navigate("channel/$channelId")
                    },
                    onHistoryClick = { navController.navigate("history") },
                    onPlaylistsClick = { navController.navigate("playlists") },
                    onWatchLaterClick = { navController.navigate("watch_later") },
                    onLikedVideosClick = { navController.navigate("liked_videos") },
                    onSettingsClick = { navController.navigate("settings") }
                ) 
            }
            composable("history") {
                HistoryScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("playlists") {
                PlaylistsScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onPlaylistClick = { playlistId ->
                        navController.navigate("playlist/$playlistId")
                    }
                )
            }
            composable("playlist/{playlistId}") { backStackEntry ->
                val playlistId = backStackEntry.arguments?.getString("playlistId") ?: ""
                PlaylistDetailsScreen(
                    playlistId = playlistId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("watch_later") {
                WatchLaterScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("liked_videos") {
                LikedVideosScreen(
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("settings") {
                SettingsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("video/{videoId}") { backStackEntry ->
                val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
                VideoDetailsScreen(
                    videoId = videoId,
                    onNavigateUp = { navController.navigateUp() },
                    onViewSound = { soundId ->
                        navController.navigate("sound/$soundId")
                    },
                    onVideoClick = { newVideoId ->
                        navController.navigate("video/$newVideoId")
                    }
                )
            }
            composable("sound/{soundId}") { backStackEntry ->
                val soundId = backStackEntry.arguments?.getString("soundId") ?: ""
                SoundDetailsScreen(
                    soundId = soundId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    }
                )
            }
            composable("notifications") {
                NotificationsScreen(onNavigateUp = { navController.navigateUp() })
            }
            composable("channel/{channelId}") { backStackEntry ->
                val channelId = backStackEntry.arguments?.getString("channelId") ?: ""
                ChannelScreen(
                    channelId = channelId,
                    onNavigateUp = { navController.navigateUp() },
                    onVideoClick = { videoId ->
                        navController.navigate("video/$videoId")
                    },
                    onEditProfileClick = {
                        navController.navigate("edit_profile")
                    }
                )
            }
            composable("edit_profile") {
                EditProfileScreen(onNavigateUp = { navController.navigateUp() })
            }
        }
        
        var showUploadScreen by remember { mutableStateOf(false) }

        if (showUploadScreen) {
            UploadScreen(onDismiss = { showUploadScreen = false })
        }
        
        if (showUploadBottomSheet) {
            UploadBottomSheet(
                onDismiss = { showUploadBottomSheet = false },
                onSimulateUpload = { 
                    showUploadScreen = true 
                }
            )
        }
    }
}
