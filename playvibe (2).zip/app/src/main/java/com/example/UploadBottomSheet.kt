package com.example

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadBottomSheet(onDismiss: () -> Unit, onSimulateUpload: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Create", fontSize = 20.sp, modifier = Modifier.padding(bottom = 16.dp))
            
            UploadOptionItem(
                icon = Icons.Filled.Upload,
                title = "Upload Video",
                onClick = { 
                    onDismiss()
                    onSimulateUpload() 
                }
            )
            
            UploadOptionItem(
                icon = Icons.Filled.VideoCall,
                title = "Create Short",
                onClick = { onDismiss() }
            )
            
            UploadOptionItem(
                icon = Icons.Filled.Videocam,
                title = "Record Video",
                onClick = { onDismiss() }
            )
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun UploadOptionItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = title, modifier = Modifier.size(32.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, fontSize = 16.sp)
    }
}

