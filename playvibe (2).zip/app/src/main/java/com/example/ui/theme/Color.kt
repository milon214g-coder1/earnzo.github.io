package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PlayVibeRed = Color(0xFFFF0000)
val DarkSurface = Color(0xFF212121)
val LightSurface = Color(0xFFF2F2F2)
val LightText = Color(0xFF606060)
val DarkText = Color(0xFFAAAAAA)
