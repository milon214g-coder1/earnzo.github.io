package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.PlayVibeRed

@Composable
fun ShortsScreen() {
    val pagerState = rememberPagerState(pageCount = { mockShorts.size })
    
    VerticalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize().background(Color.Black)
    ) { page ->
        val shortVideo = mockShorts[page]
        ShortVideoItem(video = shortVideo)
    }
}

@Composable
fun ShortVideoItem(video: Video) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Mock Video Player Background
        AsyncImage(
            model = video.thumbnailUrl,
            contentDescription = "Short Thumbnail",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        
        // Dark Overlay for text visibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.3f))
        )
        
        // Right Side Actions
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .padding(bottom = 60.dp), // Space for bottom nav
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val shortIndex = mockShorts.indexOfFirst { it.id == video.id }
            ShortAction(
                icon = Icons.Filled.ThumbUp, 
                label = formatCount(video.likesCount),
                isActive = video.isLiked,
                onClick = {
                    if (shortIndex != -1) {
                        val newIsLiked = !video.isLiked
                        val newLikesCount = if (newIsLiked) video.likesCount + 1 else video.likesCount - 1
                        mockShorts[shortIndex] = video.copy(isLiked = newIsLiked, likesCount = newLikesCount)
                    }
                }
            )
            ShortAction(icon = Icons.Filled.ThumbDown, label = "Dislike")
            ShortAction(icon = Icons.Filled.Comment, label = "456")
            ShortAction(icon = Icons.Filled.Share, label = "Share")
            
            AsyncImage(
                model = video.channel.profileImageUrl,
                contentDescription = "Channel Profile",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .padding(top = 16.dp)
                    .size(40.dp)
                    .clip(CircleShape)
            )
        }
        
        // Bottom Left Info
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
                .padding(bottom = 60.dp)
                .fillMaxWidth(0.7f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "@${video.channel.name}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                var isJoined by remember { mutableStateOf(video.channel.isJoined) }
                Button(
                    onClick = { isJoined = !isJoined },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isJoined) Color.Gray else PlayVibeRed,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(if (isJoined) "Joined" else "JoinVibe", fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = video.title,
                color = Color.White,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun ShortAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, isActive: Boolean = false, onClick: () -> Unit = {}) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally, 
        modifier = Modifier.padding(vertical = 8.dp).clickable { onClick() }
    ) {
        Icon(icon, contentDescription = label, tint = if (isActive) PlayVibeRed else Color.White, modifier = Modifier.size(32.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, color = if (isActive) PlayVibeRed else Color.White, fontSize = 12.sp)
    }
}
