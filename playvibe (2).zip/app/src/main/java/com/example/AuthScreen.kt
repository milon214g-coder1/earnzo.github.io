package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun AuthScreen(onAuthSuccess: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        PlayVibeLogo(modifier = Modifier.padding(bottom = 32.dp))
        
        Text("Welcome to PlayVibe", fontSize = 24.sp, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        if (errorMessage != null) {
            Text(errorMessage!!, color = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.height(8.dp))
        }
        
        Button(
            onClick = {
                scope.launch {
                    isLoading = true
                    errorMessage = null
                    try {
                        val auth = FirebaseManager.auth
                        val result = auth.signInWithEmailAndPassword(email, password).awaitResult().getOrThrow()
                        FirebaseManager.createUserDocument(result.user!!, email.substringBefore("@"))
                        onAuthSuccess()
                    } catch (e: Exception) {
                        try {
                            val auth = FirebaseManager.auth
                            val result = auth.createUserWithEmailAndPassword(email, password).awaitResult().getOrThrow()
                            FirebaseManager.createUserDocument(result.user!!, email.substringBefore("@"))
                            onAuthSuccess()
                        } catch (e2: Exception) {
                            errorMessage = e2.message
                        }
                    } finally {
                        isLoading = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading && email.isNotBlank() && password.isNotBlank()
        ) {
            Text("Login / Sign Up")
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        TextButton(
            onClick = {
                scope.launch {
                    isLoading = true
                    errorMessage = null
                    val result = FirebaseManager.signInAnonymously()
                    if (result.isSuccess) {
                        FirebaseManager.createUserDocument(result.getOrThrow())
                        onAuthSuccess()
                    } else {
                        errorMessage = result.exceptionOrNull()?.message
                    }
                    isLoading = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading
        ) {
            Text("Continue as Guest")
        }
        
        if (isLoading) {
            Spacer(modifier = Modifier.height(16.dp))
            CircularProgressIndicator()
        }
    }
}

// Extension to bridge Task to Kotlin Result
suspend fun <T> com.google.android.gms.tasks.Task<T>.awaitResult(): Result<T> = Result.success(this.await())
