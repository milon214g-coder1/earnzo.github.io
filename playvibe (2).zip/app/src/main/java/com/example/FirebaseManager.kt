package com.example

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

object FirebaseManager {
    val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    val storage: FirebaseStorage by lazy { FirebaseStorage.getInstance() }
    
    // Listen to Auth State
    fun listenToAuthState(onAuthStateChanged: (FirebaseUser?) -> Unit) {
        auth.addAuthStateListener { firebaseAuth ->
            onAuthStateChanged(firebaseAuth.currentUser)
        }
    }
    
    // Authentication
    suspend fun signInAnonymously(): Result<FirebaseUser> {
        return try {
            val result = auth.signInAnonymously().await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Create User Document
    suspend fun createUserDocument(user: FirebaseUser, displayName: String = "Guest") {
        val channelRef = firestore.collection("channels").document(user.uid)
        val snapshot = channelRef.get().await()
        if (!snapshot.exists()) {
            val channelData = mapOf(
                "channelName" to displayName,
                "handle" to "@${displayName.lowercase()}${user.uid.take(4)}",
                "avatarUrl" to "https://picsum.photos/seed/${user.uid}/150/150",
                "subscriberCount" to "0",
                "bio" to "New to PlayVibe!",
                "joinDate" to System.currentTimeMillis()
            )
            channelRef.set(channelData).await()
        }
    }
    
    // Upload Video to Storage
    suspend fun uploadVideo(uri: Uri, title: String, description: String, category: String, onProgress: (Float) -> Unit): Result<String> {
        return try {
            val user = auth.currentUser ?: throw Exception("Not authenticated")
            val videoId = UUID.randomUUID().toString()
            val videoRef = storage.reference.child("videos/$videoId.mp4")
            
            // Note: In a real app, we'd use a more robust upload mechanism.
            // For simplicity, we just putFile and await.
            videoRef.putFile(uri).await()
            val downloadUrl = videoRef.downloadUrl.await().toString()
            
            // Save to Firestore
            val videoData = mapOf(
                "id" to videoId,
                "title" to title,
                "description" to description,
                "uploaderChannelId" to user.uid,
                "thumbnailUrl" to "https://picsum.photos/seed/$videoId/600/300",
                "videoUrl" to downloadUrl,
                "viewCount" to "0",
                "likeCount" to 0,
                "category" to category,
                "viralScore" to 0,
                "uploadDate" to System.currentTimeMillis().toString(),
                "isCopyrightClaimed" to false
            )
            firestore.collection("videos").document(videoId).set(videoData).await()
            Result.success(videoId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // User Actions
    fun toggleLike(videoId: String, isLiked: Boolean) {
        val user = auth.currentUser ?: return
        val doc = firestore.collection("videos").document(videoId)
        firestore.runTransaction { transaction ->
            val snapshot = transaction.get(doc)
            val currentLikes = snapshot.getLong("likeCount") ?: 0
            val newLikes = if (isLiked) currentLikes + 1 else currentLikes - 1
            transaction.update(doc, "likeCount", newLikes.coerceAtLeast(0))
        }
        
        val userLiked = firestore.collection("users").document(user.uid).collection("likedVideos").document(videoId)
        if (isLiked) userLiked.set(mapOf("timestamp" to System.currentTimeMillis()))
        else userLiked.delete()
    }
    
    fun addToWatchHistory(videoId: String) {
        val user = auth.currentUser ?: return
        firestore.collection("users").document(user.uid).collection("history")
            .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
    }
    
    fun addToWatchLater(videoId: String) {
        val user = auth.currentUser ?: return
        firestore.collection("users").document(user.uid).collection("watchLater")
            .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
    }
    
    fun createPlaylist(name: String, onComplete: () -> Unit = {}) {
        val user = auth.currentUser ?: return
        val playlistId = UUID.randomUUID().toString()
        firestore.collection("users").document(user.uid).collection("playlists")
            .document(playlistId).set(mapOf("name" to name)).addOnSuccessListener { onComplete() }
    }
    
    fun addToPlaylist(playlistId: String, videoId: String) {
        val user = auth.currentUser ?: return
        firestore.collection("users").document(user.uid).collection("playlists")
            .document(playlistId).collection("videos")
            .document(videoId).set(mapOf("timestamp" to System.currentTimeMillis()))
    }
    
    fun initFirebaseData() {
        // Listen to channels to build a lookup map
        firestore.collection("channels").addSnapshotListener { channelSnapshot, _ ->
            if (channelSnapshot != null) {
                val parsedChannels = channelSnapshot.documents.map { doc ->
                    Channel(
                        id = doc.id,
                        name = doc.getString("channelName") ?: "Unknown",
                        profileImageUrl = doc.getString("avatarUrl") ?: "https://picsum.photos/200",
                        vibersCount = doc.getString("subscriberCount") ?: "0",
                        isJoined = false
                    )
                }
                val channels = parsedChannels.associateBy { it.id }
                
                mockChannels.clear()
                mockChannels.addAll(parsedChannels)
                
                auth.currentUser?.let { user ->
                    channels[user.uid]?.let { channel ->
                        currentUserChannel = channel
                    }
                }
                
                // Then listen to videos
                firestore.collection("videos").addSnapshotListener { videoSnapshot, _ ->
                    if (videoSnapshot != null && !videoSnapshot.isEmpty) {
                        val user = auth.currentUser
                        if (user != null) {
                            firestore.collection("users").document(user.uid).collection("likedVideos").addSnapshotListener { likesSnapshot, _ ->
                                val likedIds = likesSnapshot?.documents?.map { it.id } ?: emptyList()
                                
                                val parsedVideos = videoSnapshot.documents.map { doc ->
                                    val uploaderId = doc.getString("uploaderChannelId") ?: ""
                                    val channel = channels[uploaderId] ?: mockChannels.firstOrNull() ?: Channel("unknown", "Unknown", "", "0", false) // fallback
                                    val vidId = doc.getString("id") ?: doc.id
                                    Video(
                                        id = vidId,
                                        title = doc.getString("title") ?: "",
                                        thumbnailUrl = doc.getString("thumbnailUrl") ?: "",
                                        channel = channel,
                                        viewCount = doc.getString("viewCount") ?: "0",
                                        uploadDate = doc.getString("uploadDate") ?: "",
                                        duration = doc.getString("duration") ?: "0:00",
                                        videoUrl = doc.getString("videoUrl") ?: "",
                                        description = doc.getString("description") ?: "",
                                        likesCount = doc.getLong("likeCount")?.toInt() ?: 0,
                                        isLiked = likedIds.contains(vidId),
                                        viralScore = doc.getLong("viralScore")?.toInt() ?: 0,
                                        category = doc.getString("category") ?: "All",
                                        soundId = doc.getString("soundId"),
                                        isCopyrightClaimed = doc.getBoolean("isCopyrightClaimed") ?: false,
                                        originalOwnerChannelName = doc.getString("originalOwnerChannelName")
                                    )
                                }
                                
                                mockVideos.clear()
                                mockVideos.addAll(parsedVideos)
                                
                                val shorts = parsedVideos.filter { it.duration == "0:00" }
                                if (shorts.isNotEmpty()) {
                                    mockShorts.clear()
                                    mockShorts.addAll(shorts)
                                }
                            }
                            
                            // History
                            firestore.collection("users").document(user.uid).collection("history").addSnapshotListener { histSnap, _ ->
                                val histIds = histSnap?.documents?.map { it.id } ?: emptyList()
                                val histVids = mockVideos.filter { histIds.contains(it.id) }
                                mockWatchHistory.clear()
                                mockWatchHistory.addAll(histVids)
                            }
                            
                            // Watch Later
                            firestore.collection("users").document(user.uid).collection("watchLater").addSnapshotListener { wlSnap, _ ->
                                val wlIds = wlSnap?.documents?.map { it.id } ?: emptyList()
                                val wlVids = mockVideos.filter { wlIds.contains(it.id) }
                                mockWatchLater.clear()
                                mockWatchLater.addAll(wlVids)
                            }
                            
                            // Playlists
                            firestore.collection("users").document(user.uid).collection("playlists").addSnapshotListener { plSnap, _ ->
                                if (plSnap != null) {
                                    val newPlaylists = plSnap.documents.map { pDoc ->
                                        val pName = pDoc.getString("name") ?: "Playlist"
                                        val pl = Playlist(pDoc.id, pName, mutableListOf())
                                        pDoc.reference.collection("videos").addSnapshotListener { pVidSnap, _ ->
                                            val pVidIds = pVidSnap?.documents?.map { it.id } ?: emptyList()
                                            pl.videos.clear()
                                            pl.videos.addAll(mockVideos.filter { pVidIds.contains(it.id) })
                                        }
                                        pl
                                    }
                                    mockPlaylists.clear()
                                    mockPlaylists.addAll(newPlaylists)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
